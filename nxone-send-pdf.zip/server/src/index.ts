import { and, eq, gt, inArray } from "drizzle-orm";
import { drizzle, type DrizzleD1Database } from "drizzle-orm/d1";
import {
  LOGIN_TOKEN_TTL_MS, SESSION_TTL_MS, clearedCookie, hashToken, isEmail,
  normaliseEmail, randomToken, readCookie, sessionCookie, type Session
} from "./auth/tokens";
import { PLANS, TRIAL_DAYS, entitlementsFor, planById, priceFor } from "./billing/plans";
import { paymentProvider } from "./billing/provider";
import { linkProvider, type PaymentNotice } from "./payments/links";
import { leaks, newToken, refusalFor, stateOf } from "./portal/share";
import { checkPdf, safeFileName } from "./portal/outgoing";
import * as schema from "./db/schema";
import { emailSender, inviteEmail, loginEmail } from "./http/email";
import { corsHeaders, json, problem, rateLimit } from "./http/respond";
import { buildDigest, digestEmail } from "./notify/digest";
import { receiptService } from "./receipts/read";
import { changesSince, mergePush, type SyncRecord } from "./sync/merge";
import {
  ROLES, can, canAddSeat, isRole, refuseInvite, refuseRemoval, refuseRoleChange, seatCount, type Role
} from "./team/seats";

export interface Env {
  DB: D1Database;
  SESSIONS: KVNamespace;
  APP_ORIGIN: string;
  EMAIL_PROVIDER?: string;
  RESEND_API_KEY?: string;
  EMAIL_FROM?: string;
  /** Set when a receipt reading service is connected. Without it, the app says so plainly. */
  RECEIPT_PROVIDER?: string;
  GOOGLE_VISION_KEY?: string;
  /** Set when a payment provider is connected. Without these, checkout says so plainly. */
  PAYMENT_PROVIDER?: string;
  RAZORPAY_KEY_ID?: string;
  RAZORPAY_KEY_SECRET?: string;
  /** Maps our plan and period to the provider's own plan ids, as JSON. */
  RAZORPAY_PLANS?: string;
  /** Razorpay signs webhooks with its own secret, separate from the API key. */
  RAZORPAY_WEBHOOK_SECRET?: string;
}

const uid = (prefix: string) => `${prefix}_${crypto.randomUUID().replace(/-/g, "").slice(0, 20)}`;

/** Everything behind a login goes through here, so no route can forget to check. */
async function currentSession(req: Request, env: Env): Promise<{ token: string; session: Session } | null> {
  const token = readCookie(req.headers.get("Cookie"), "nxone_session");
  if (!token) return null;
  const raw = await env.SESSIONS.get(`session:${token}`);
  if (!raw) return null;
  const session = JSON.parse(raw) as Session;
  if (session.expiresAt < Date.now()) {
    await env.SESSIONS.delete(`session:${token}`);
    return null;
  }
  return { token, session };
}

/** A person can only ever touch an organisation they belong to. */
async function membership(db: DrizzleD1Database<typeof schema>, userId: string, orgId: string) {
  const rows = await db.select().from(schema.memberships)
    .where(and(eq(schema.memberships.userId, userId), eq(schema.memberships.orgId, orgId))).limit(1);
  return rows[0];
}

/** The plan an organisation is on, and what that allows today. */
async function allowance(db: DrizzleD1Database<typeof schema>, orgId: string) {
  const org = (await db.select().from(schema.organisations).where(eq(schema.organisations.id, orgId)).limit(1))[0];
  if (!org) return null;
  return { org, ...entitlementsFor(org.plan, org.trialEndsAt?.getTime() ?? null) };
}

/**
 * Keeps the PDF behind a shared link in KV, beside the sessions, so the link can offer a download.
 * Returns whether a PDF is now there. A missing or bad PDF clears any older one rather than
 * failing the share: the page still works without the download.
 */
async function keepPdf(env: Env, token: string, pdf: unknown, number: string, expiresAt: Date | null): Promise<boolean> {
  const checked = pdf === undefined ? null : checkPdf(pdf);
  if (!checked || !checked.ok) {
    if (checked && !checked.ok) console.warn("Shared without a PDF:", checked.says);
    await Promise.all([env.SESSIONS.delete(`pdf:${token}`), env.SESSIONS.delete(`pdfname:${token}`)]);
    return false;
  }
  const ttl = expiresAt ? Math.max(60, Math.ceil((expiresAt.getTime() - Date.now()) / 1000)) : undefined;
  const options = ttl ? { expirationTtl: ttl } : undefined;
  await env.SESSIONS.put(`pdf:${token}`, checked.bytes, options);
  await env.SESSIONS.put(`pdfname:${token}`, safeFileName(number), options);
  return true;
}

/** An invitation is good for a week: long enough for somebody on holiday, short enough to matter. */
const INVITE_TTL_MS = 7 * 24 * 60 * 60 * 1000;

/** How many seats are taken, counting invitations nobody has opened yet. */
async function seatNumbers(db: DrizzleD1Database<typeof schema>, orgId: string) {
  const members = await db.select().from(schema.memberships).where(eq(schema.memberships.orgId, orgId));
  const invites = await db.select().from(schema.invitations).where(eq(schema.invitations.orgId, orgId));
  const pending = invites.filter((i) => !i.acceptedAt && !i.revokedAt && i.expiresAt.getTime() > Date.now());
  return { memberRows: members, pendingRows: pending, members: members.length, pending: pending.length };
}

/** Everything the People screen shows, assembled once so every route answers the same way. */
async function teamView(db: DrizzleD1Database<typeof schema>, orgId: string, viewerId: string) {
  const allowed = await allowance(db, orgId);
  const org = allowed?.org;
  const { memberRows, pendingRows } = await seatNumbers(db, orgId);
  const people = memberRows.length
    ? await db.select({ id: schema.users.id, email: schema.users.email, name: schema.users.name, lastSeenAt: schema.users.lastSeenAt })
        .from(schema.users).where(inArray(schema.users.id, memberRows.map((m) => m.userId)))
    : [];

  const members = memberRows.map((m) => {
    const person = people.find((u) => u.id === m.userId);
    return {
      userId: m.userId,
      email: person?.email ?? "",
      name: person?.name ?? null,
      role: m.role as Role,
      joinedAt: m.createdAt.getTime(),
      lastSeenAt: person?.lastSeenAt?.getTime() ?? null,
      isYou: m.userId === viewerId
    };
  });

  const pending = pendingRows.map((i) => ({
    id: i.id, email: i.email, role: i.role as Role, invitedAt: i.createdAt.getTime(), expiresAt: i.expiresAt.getTime()
  }));

  const plan = allowed?.plan ?? planById("free");
  const country = org?.country ?? "IN";
  const viewer = memberRows.find((m) => m.userId === viewerId);

  return {
    organisation: { id: orgId, name: org?.name ?? "", country },
    plan: { id: plan.id, name: plan.name, trialing: allowed?.trialing ?? false },
    you: { userId: viewerId, role: (viewer?.role ?? "readonly") as Role, can: can(viewer?.role ?? "readonly") },
    roles: ROLES,
    members,
    pending,
    counts: seatCount(plan, members.length, pending.length),
    seats: canAddSeat(plan, country, members.length, pending.length)
  };
}

async function audit(db: DrizzleD1Database<typeof schema>, req: Request, entry: { orgId: string; userId?: string; action: string; recordKind?: string; recordId?: string; summary?: string }) {
  await db.insert(schema.auditLog).values({
    id: uid("au"), at: new Date(), ip: req.headers.get("CF-Connecting-IP") ?? undefined,
    userAgent: req.headers.get("User-Agent")?.slice(0, 200) ?? undefined, ...entry
  });
}

/** Builds the digest for an organisation from the records it has synced. */
async function digestFor(db: DrizzleD1Database<typeof schema>, orgId: string, today: string) {
  const rows = await db.select().from(schema.records).where(eq(schema.records.orgId, orgId));
  const records = rows.filter((r) => !r.deletedAt).map((r) => ({ kind: r.kind, body: JSON.parse(r.body) as Record<string, unknown> }));
  const profile = records.find((r) => r.kind === "profile")?.body as { name?: string; currency?: string } | undefined;
  return buildDigest({
    businessName: profile?.name,
    currency: profile?.currency ?? "INR",
    today,
    records
  });
}

export default {
  /**
   * The scheduled run. Sending is deliberately conservative: only people who asked, only when
   * there is something to say, and never more than once a day however often this runs.
   */
  async scheduled(_event: ScheduledController, env: Env): Promise<void> {
    const db = drizzle(env.DB, { schema });
    const today = new Date().toISOString().slice(0, 10);
    const sender = emailSender(env);

    const wanted = await db.select({
      prefs: schema.notificationPrefs,
      email: schema.users.email
    }).from(schema.notificationPrefs)
      .innerJoin(schema.users, eq(schema.notificationPrefs.userId, schema.users.id))
      .where(eq(schema.notificationPrefs.weeklyDigest, true));

    for (const row of wanted) {
      const lastSent = row.prefs.lastSentAt?.getTime() ?? 0;
      if (Date.now() - lastSent < 20 * 60 * 60 * 1000) continue;

      // reminders are part of Pro, so a lapsed plan simply stops sending rather than failing
      const org = (await db.select().from(schema.organisations).where(eq(schema.organisations.id, row.prefs.orgId)).limit(1))[0];
      if (!org || !entitlementsFor(org.plan, org.trialEndsAt?.getTime() ?? null).limits.reminders) continue;

      const digest = await digestFor(db, row.prefs.orgId, today);
      if (!digest.worthSending) continue;

      const mail = digestEmail(digest, env.APP_ORIGIN);
      const sent = await sender.send({ to: row.email, subject: mail.subject, text: mail.text });
      if (sent) {
        await db.update(schema.notificationPrefs).set({ lastSentAt: new Date() }).where(eq(schema.notificationPrefs.id, row.prefs.id));
      }
    }
  },

  async fetch(req: Request, env: Env): Promise<Response> {
    const url = new URL(req.url);
    /**
     * The app is allowed, and any local port while the API itself is running locally, so that
     * development works without widening what a deployed API accepts.
     */
    const origin = req.headers.get("Origin");
    const isLocalApi = url.hostname === "localhost" || url.hostname === "127.0.0.1";
    const localOrigin = Boolean(origin && /^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(origin));
    const allowed = [env.APP_ORIGIN, ...(isLocalApi && localOrigin && origin ? [origin] : [])];
    const cors = corsHeaders(origin, allowed);
    const secure = url.protocol === "https:";

    if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });

    const db = drizzle(env.DB, { schema });
    const reply = (res: Response) => {
      for (const [k, v] of Object.entries(cors)) res.headers.set(k, String(v));
      return res;
    };

    try {
      /* ---------- health ---------- */
      if (url.pathname === "/health") return reply(json({ ok: true, time: new Date().toISOString() }));

      /* ---------- ask for a login link ---------- */
      if (url.pathname === "/auth/request" && req.method === "POST") {
        const { email } = (await req.json()) as { email?: string };
        if (!email || !isEmail(email)) return reply(problem(400, "That does not look like an email address."));

        const address = normaliseEmail(email);
        const ip = req.headers.get("CF-Connecting-IP") ?? "unknown";
        if (!(await rateLimit(env.SESSIONS, `login:${address}`, 5, 15 * 60 * 1000))
          || !(await rateLimit(env.SESSIONS, `loginip:${ip}`, 20, 15 * 60 * 1000))) {
          return reply(problem(429, "Too many attempts. Try again in a few minutes."));
        }

        const token = randomToken();
        await db.insert(schema.loginTokens).values({
          tokenHash: await hashToken(token), email: address,
          expiresAt: new Date(Date.now() + LOGIN_TOKEN_TTL_MS), createdAt: new Date(), requestIp: ip
        });

        const link = `${env.APP_ORIGIN}/sign-in/?token=${token}`;
        const message = { ...loginEmail(link, LOGIN_TOKEN_TTL_MS / 60000), to: address };
        const sent = await emailSender(env).send(message);

        // the answer never says whether the address is known, which would be a way to enumerate users
        return reply(json({ ok: true, sent }));
      }

      /* ---------- use the link ---------- */
      if (url.pathname === "/auth/verify" && req.method === "POST") {
        const { token } = (await req.json()) as { token?: string };
        if (!token) return reply(problem(400, "No sign-in token was sent."));

        const hash = await hashToken(token);
        const rows = await db.select().from(schema.loginTokens).where(eq(schema.loginTokens.tokenHash, hash)).limit(1);
        const record = rows[0];
        if (!record || record.usedAt || record.expiresAt.getTime() < Date.now()) {
          return reply(problem(401, "That link has expired or has already been used. Please ask for a new one."));
        }
        await db.update(schema.loginTokens).set({ usedAt: new Date() }).where(eq(schema.loginTokens.tokenHash, hash));

        let user = (await db.select().from(schema.users).where(eq(schema.users.email, record.email)).limit(1))[0];
        let orgId: string | undefined;

        if (!user) {
          // first sign in: the person and their organisation are created together
          user = { id: uid("us"), email: record.email, name: null, createdAt: new Date(), lastSeenAt: new Date(), deletionRequestedAt: null };
          await db.insert(schema.users).values(user);
          orgId = uid("or");
          await db.insert(schema.organisations).values({
            id: orgId, name: "My business", country: "IN", currency: "INR", plan: "free", region: "auto",
            // a fortnight of Pro, without a card, because sync is only worth paying for once it is useful
            trialEndsAt: new Date(Date.now() + TRIAL_DAYS * 24 * 60 * 60 * 1000),
            createdAt: new Date()
          });
          await db.insert(schema.memberships).values({ id: uid("me"), userId: user.id, orgId, role: "owner", createdAt: new Date() });
          await audit(db, req, { orgId, userId: user.id, action: "org.created" });
        } else {
          await db.update(schema.users).set({ lastSeenAt: new Date() }).where(eq(schema.users.id, user.id));
          orgId = (await db.select().from(schema.memberships).where(eq(schema.memberships.userId, user.id)).limit(1))[0]?.orgId;
        }

        const sessionToken = randomToken();
        const session: Session = { userId: user.id, email: user.email, orgId, createdAt: Date.now(), expiresAt: Date.now() + SESSION_TTL_MS };
        await env.SESSIONS.put(`session:${sessionToken}`, JSON.stringify(session), { expirationTtl: SESSION_TTL_MS / 1000 });
        await audit(db, req, { orgId: orgId!, userId: user.id, action: "auth.signed-in" });

        return reply(json({ ok: true, user: { email: user.email, name: user.name }, orgId },
          { headers: { "Set-Cookie": sessionCookie(sessionToken, secure) } }));
      }

      /* ---------- who am I ---------- */
      if (url.pathname === "/auth/me") {
        const found = await currentSession(req, env);
        if (!found) return reply(problem(401, "Not signed in."));
        const orgs = await db.select({ id: schema.organisations.id, name: schema.organisations.name, plan: schema.organisations.plan, role: schema.memberships.role })
          .from(schema.memberships).innerJoin(schema.organisations, eq(schema.memberships.orgId, schema.organisations.id))
          .where(eq(schema.memberships.userId, found.session.userId));
        const plan = found.session.orgId ? await allowance(db, found.session.orgId) : null;
        return reply(json({
          user: { email: found.session.email },
          orgId: found.session.orgId,
          organisations: orgs,
          plan: plan ? { id: plan.plan.id, name: plan.plan.name, trialing: plan.trialing, trialEndsAt: plan.trialEndsAt, limits: plan.limits } : null
        }));
      }

      /* ---------- sign out ---------- */
      if (url.pathname === "/auth/sign-out" && req.method === "POST") {
        const found = await currentSession(req, env);
        if (found) await env.SESSIONS.delete(`session:${found.token}`);
        return reply(json({ ok: true }, { headers: { "Set-Cookie": clearedCookie(secure) } }));
      }

      /* ---------- who is on the team ---------- */
      if (url.pathname === "/team" && req.method === "GET") {
        const found = await currentSession(req, env);
        if (!found?.session.orgId) return reply(problem(401, "Not signed in."));
        const member = await membership(db, found.session.userId, found.session.orgId);
        if (!member) return reply(problem(403, "You do not have access to that organisation."));
        return reply(json(await teamView(db, found.session.orgId, found.session.userId)));
      }

      /* ---------- ask somebody to join ---------- */
      if (url.pathname === "/team/invite" && req.method === "POST") {
        const found = await currentSession(req, env);
        if (!found?.session.orgId) return reply(problem(401, "Not signed in."));
        const orgId = found.session.orgId;
        const member = await membership(db, found.session.userId, orgId);
        if (!member || !can(member.role).manageTeam) return reply(problem(403, "Only an owner or a manager can add people."));

        const { email, role } = (await req.json()) as { email?: string; role?: string };
        if (!email || !isEmail(email)) return reply(problem(400, "That does not look like an email address."));
        const wanted: Role = isRole(role) ? role : "member";
        if (wanted === "owner" && member.role !== "owner") return reply(problem(403, "Only an owner can make somebody else an owner."));

        const address = normaliseEmail(email);
        const view = await teamView(db, orgId, found.session.userId);
        const already = refuseInvite(view.members, view.pending, address);
        if (already) return reply(problem(409, already));
        if (!view.seats.allowed) return reply(problem(402, view.seats.message, { plan: view.plan.id, seats: view.seats.seats }));

        const token = randomToken();
        const invite = {
          id: uid("in"), orgId, email: address, role: wanted, tokenHash: await hashToken(token),
          invitedBy: found.session.userId, expiresAt: new Date(Date.now() + INVITE_TTL_MS),
          acceptedAt: null, revokedAt: null, createdAt: new Date()
        };
        await db.insert(schema.invitations).values(invite);

        const org = (await db.select().from(schema.organisations).where(eq(schema.organisations.id, orgId)).limit(1))[0];
        const link = `${env.APP_ORIGIN}/join/?token=${token}`;
        const sent = await emailSender(env).send({
          ...inviteEmail(link, {
            org: org?.name ?? "a business on NXOne",
            invitedBy: found.session.email,
            role: ROLES.find((r) => r.id === wanted)!.name.toLowerCase(),
            days: Math.round(INVITE_TTL_MS / 86_400_000)
          }),
          to: address
        });
        await audit(db, req, { orgId, userId: found.session.userId, action: "team.invited", summary: `${address} as ${wanted}` });

        return reply(json({ ok: true, sent, team: await teamView(db, orgId, found.session.userId) }));
      }

      /* ---------- take back an invitation ---------- */
      if (url.pathname === "/team/invite/revoke" && req.method === "POST") {
        const found = await currentSession(req, env);
        if (!found?.session.orgId) return reply(problem(401, "Not signed in."));
        const orgId = found.session.orgId;
        const member = await membership(db, found.session.userId, orgId);
        if (!member || !can(member.role).manageTeam) return reply(problem(403, "Only an owner or a manager can do that."));

        const { id } = (await req.json()) as { id?: string };
        if (!id) return reply(problem(400, "Which invitation?"));
        const row = (await db.select().from(schema.invitations).where(and(eq(schema.invitations.id, id), eq(schema.invitations.orgId, orgId))).limit(1))[0];
        if (!row) return reply(problem(404, "That invitation no longer exists."));
        await db.update(schema.invitations).set({ revokedAt: new Date() }).where(eq(schema.invitations.id, id));
        await audit(db, req, { orgId, userId: found.session.userId, action: "team.invite-revoked", summary: row.email });
        return reply(json({ ok: true, team: await teamView(db, orgId, found.session.userId) }));
      }

      /* ---------- accept one ---------- */
      if (url.pathname === "/team/accept" && req.method === "POST") {
        const { token } = (await req.json()) as { token?: string };
        if (!token) return reply(problem(400, "No invitation token was sent."));

        const hash = await hashToken(token);
        const invite = (await db.select().from(schema.invitations).where(eq(schema.invitations.tokenHash, hash)).limit(1))[0];
        if (!invite || invite.acceptedAt || invite.revokedAt || invite.expiresAt.getTime() < Date.now()) {
          return reply(problem(401, "That invitation has expired or has already been used. Ask whoever sent it for another."));
        }

        const org = (await db.select().from(schema.organisations).where(eq(schema.organisations.id, invite.orgId)).limit(1))[0];
        if (!org) return reply(problem(404, "That business no longer exists."));

        // The seat is checked again here: the plan may have changed between sending and opening.
        const allowed = await allowance(db, invite.orgId);
        const counts = await seatNumbers(db, invite.orgId);
        // The pending invitation is not counted here: it is the one being taken up.
        if (allowed && !canAddSeat(allowed.plan, org.country, counts.members, 0).allowed) {
          return reply(problem(402, "There is no seat free on this plan any more. Ask whoever invited you to add one."));
        }

        let user = (await db.select().from(schema.users).where(eq(schema.users.email, invite.email)).limit(1))[0];
        if (!user) {
          user = { id: uid("us"), email: invite.email, name: null, createdAt: new Date(), lastSeenAt: new Date(), deletionRequestedAt: null };
          await db.insert(schema.users).values(user);
        } else {
          await db.update(schema.users).set({ lastSeenAt: new Date() }).where(eq(schema.users.id, user.id));
        }

        const existing = await membership(db, user.id, invite.orgId);
        if (!existing) {
          await db.insert(schema.memberships).values({ id: uid("me"), userId: user.id, orgId: invite.orgId, role: invite.role, createdAt: new Date() });
        }
        await db.update(schema.invitations).set({ acceptedAt: new Date() }).where(eq(schema.invitations.id, invite.id));

        const sessionToken = randomToken();
        const session: Session = { userId: user.id, email: user.email, orgId: invite.orgId, createdAt: Date.now(), expiresAt: Date.now() + SESSION_TTL_MS };
        await env.SESSIONS.put(`session:${sessionToken}`, JSON.stringify(session), { expirationTtl: SESSION_TTL_MS / 1000 });
        await audit(db, req, { orgId: invite.orgId, userId: user.id, action: "team.joined", summary: `as ${invite.role}` });

        return reply(json({
          ok: true,
          user: { email: user.email },
          orgId: invite.orgId,
          organisation: { name: org.name },
          role: invite.role,
          can: can(invite.role)
        }, { headers: { "Set-Cookie": sessionCookie(sessionToken, secure) } }));
      }

      /* ---------- change what somebody can do ---------- */
      if (url.pathname === "/team/role" && req.method === "POST") {
        const found = await currentSession(req, env);
        if (!found?.session.orgId) return reply(problem(401, "Not signed in."));
        const orgId = found.session.orgId;
        const member = await membership(db, found.session.userId, orgId);
        if (!member || member.role !== "owner") return reply(problem(403, "Only an owner can change what somebody can do."));

        const { userId, role } = (await req.json()) as { userId?: string; role?: string };
        if (!userId || !isRole(role)) return reply(problem(400, "Say who, and which role."));

        const rows = await db.select().from(schema.memberships).where(eq(schema.memberships.orgId, orgId));
        const refusal = refuseRoleChange(rows.map((r) => ({ userId: r.userId, role: r.role as Role })), userId, role);
        if (refusal) return reply(problem(409, refusal));

        await db.update(schema.memberships).set({ role })
          .where(and(eq(schema.memberships.orgId, orgId), eq(schema.memberships.userId, userId)));
        await audit(db, req, { orgId, userId: found.session.userId, action: "team.role-changed", summary: `${userId} to ${role}` });
        return reply(json({ ok: true, team: await teamView(db, orgId, found.session.userId) }));
      }

      /* ---------- take somebody off ---------- */
      if (url.pathname === "/team/remove" && req.method === "POST") {
        const found = await currentSession(req, env);
        if (!found?.session.orgId) return reply(problem(401, "Not signed in."));
        const orgId = found.session.orgId;
        const member = await membership(db, found.session.userId, orgId);
        if (!member || !can(member.role).manageTeam) return reply(problem(403, "Only an owner or a manager can do that."));

        const { userId } = (await req.json()) as { userId?: string };
        if (!userId) return reply(problem(400, "Say who."));

        const rows = await db.select().from(schema.memberships).where(eq(schema.memberships.orgId, orgId));
        const refusal = refuseRemoval(rows.map((r) => ({ userId: r.userId, role: r.role as Role })), userId);
        if (refusal) return reply(problem(409, refusal));
        const target = rows.find((r) => r.userId === userId)!;
        if (target.role === "owner" && member.role !== "owner") return reply(problem(403, "Only an owner can remove another owner."));

        await db.delete(schema.memberships).where(and(eq(schema.memberships.orgId, orgId), eq(schema.memberships.userId, userId)));
        await audit(db, req, { orgId, userId: found.session.userId, action: "team.removed", summary: userId });

        /**
         * Their copy of the books stays on their own device. We say so rather than implying a
         * removal reaches into somebody's laptop, which it cannot and should not.
         */
        return reply(json({ ok: true, note: "They can no longer sync or see anything new. What is already on their own device stays there.", team: await teamView(db, orgId, found.session.userId) }));
      }

      /* ---------- pull changes ---------- */
      if (url.pathname === "/sync/pull") {
        const found = await currentSession(req, env);
        if (!found?.session.orgId) return reply(problem(401, "Not signed in."));
        if (!(await membership(db, found.session.userId, found.session.orgId))) return reply(problem(403, "You do not have access to that organisation."));

        const since = Number(url.searchParams.get("since") ?? 0);
        const rows = await db.select().from(schema.records)
          .where(and(eq(schema.records.orgId, found.session.orgId), gt(schema.records.updatedAt, new Date(since))))
          .limit(501);

        const asSync: SyncRecord[] = rows.map((r) => ({
          kind: r.kind, localId: r.localId, body: JSON.parse(r.body), version: r.version,
          updatedAt: r.updatedAt.getTime(), deletedAt: r.deletedAt?.getTime() ?? null
        }));
        return reply(json(changesSince(asSync, since)));
      }

      /* ---------- push changes ---------- */
      if (url.pathname === "/sync/push" && req.method === "POST") {
        const found = await currentSession(req, env);
        if (!found?.session.orgId) return reply(problem(401, "Not signed in."));
        const member = await membership(db, found.session.userId, found.session.orgId);
        if (!member) return reply(problem(403, "You do not have access to that organisation."));
        if (!can(member.role).write) {
          return reply(problem(403, member.role === "accountant"
            ? "An accountant seat can see the books and export them, but cannot change them."
            : "Your access to this organisation is read only."));
        }

        const allowed = await allowance(db, found.session.orgId);
        const { records } = (await req.json()) as { records: SyncRecord[] };
        if (!Array.isArray(records) || records.length > 500) return reply(problem(400, "Send up to 500 records at a time."));
        if (records.length === 0) return reply(json({ applied: [], rejected: [], cursor: Date.now() }));

        const orgId = found.session.orgId;
        const existingRows = await db.select().from(schema.records)
          .where(and(eq(schema.records.orgId, orgId), inArray(schema.records.localId, records.map((r) => r.localId))));

        const existing = new Map<string, SyncRecord>(existingRows.map((r) => [`${r.kind}:${r.localId}`, {
          kind: r.kind, localId: r.localId, body: JSON.parse(r.body), version: r.version,
          updatedAt: r.updatedAt.getTime(), deletedAt: r.deletedAt?.getTime() ?? null
        }]));
        const byKeyId = new Map(existingRows.map((r) => [`${r.kind}:${r.localId}`, r.id]));

        /**
         * A free account is held, but not without limit. We refuse politely and say how to lift
         * it, rather than failing silently and leaving somebody's work on one device.
         */
        if (allowed?.limits.records !== null && allowed?.limits.records !== undefined) {
          const held = await db.select({ id: schema.records.id }).from(schema.records).where(eq(schema.records.orgId, orgId));
          const newOnes = records.filter((r) => !existing.has(`${r.kind}:${r.localId}`)).length;
          if (held.length + newOnes > allowed.limits.records) {
            return reply(problem(402, `A free account holds up to ${allowed.limits.records} records, and this would go past that. Everything stays safe on your device, and Pro removes the limit.`, { plan: allowed.plan.id, held: held.length, limit: allowed.limits.records }));
          }
        }

        const result = mergePush(records, existing);
        const at = new Date();

        for (const rec of result.applied) {
          const key = `${rec.kind}:${rec.localId}`;
          const rowId = byKeyId.get(key);
          const values = {
            orgId, kind: rec.kind, localId: rec.localId, body: JSON.stringify(rec.body),
            version: rec.version, updatedAt: at, deletedAt: rec.deletedAt ? new Date(rec.deletedAt) : null,
            updatedBy: found.session.userId
          };
          if (rowId) await db.update(schema.records).set(values).where(eq(schema.records.id, rowId));
          else await db.insert(schema.records).values({ id: uid("re"), ...values });
        }

        await audit(db, req, {
          orgId, userId: found.session.userId, action: "sync.push",
          summary: `${result.applied.length} applied, ${result.rejected.length} rejected`
        });

        return reply(json({ applied: result.applied.map((r) => ({ kind: r.kind, localId: r.localId, version: r.version })), rejected: result.rejected, cursor: at.getTime() }));
      }

      /* ---------- what the plans are ---------- */
      if (url.pathname === "/billing/plans") {
        const found = await currentSession(req, env);
        const country = (url.searchParams.get("country")
          ?? (found?.session.orgId ? (await allowance(db, found.session.orgId))?.org.country : null)
          ?? "IN").toUpperCase();

        return reply(json({
          country,
          provider: paymentProvider(env).name,
          checkoutConnected: paymentProvider(env).live,
          plans: PLANS.map((p) => ({ id: p.id, name: p.name, summary: p.summary, features: p.features, limits: p.limits, price: priceFor(p, country) }))
        }));
      }

      /* ---------- a link a customer can open to see their invoice ---------- */
      if (url.pathname === "/portal/share" && req.method === "POST") {
        const found = await currentSession(req, env);
        if (!found?.session.orgId) return reply(problem(401, "Not signed in."));

        const body = await req.json().catch(() => null) as {
          documentId?: string; number?: string; snapshot?: unknown; expiresInDays?: number; pdf?: string;
        } | null;
        if (!body?.documentId || !body.number || !body.snapshot) {
          return reply(problem(400, "A document and its contents are needed."));
        }

        // The snapshot is built on the device, so it is checked here rather than trusted: a
        // field that should never reach a customer must not reach one because a future version
        // of the app widened what it sends.
        const found_leaks = leaks(body.snapshot);
        if (found_leaks.length > 0) {
          console.error("Refused a snapshot carrying private fields:", found_leaks.join(", "));
          return reply(problem(400, "That document carries information that must not be shared."));
        }

        // One live link per document: a second link for the same invoice is one more copy to
        // remember to withdraw.
        const existing = await db.select().from(schema.sharedDocuments)
          .where(and(
            eq(schema.sharedDocuments.orgId, found.session.orgId),
            eq(schema.sharedDocuments.documentId, body.documentId)
          )).limit(1);

        const live = existing[0] && stateOf({
          ...existing[0],
          createdAt: existing[0].createdAt ?? new Date(),
          expiresAt: existing[0].expiresAt ?? undefined,
          revokedAt: existing[0].revokedAt ?? undefined
        } as never) === "live";

        if (live && existing[0]) {
          // Refresh what it shows, so a corrected invoice can be re-shared on the same link.
          await db.update(schema.sharedDocuments)
            .set({ snapshot: JSON.stringify(body.snapshot), number: body.number })
            .where(eq(schema.sharedDocuments.id, existing[0].id));
          // The PDF is replaced with the page, or removed, so the download never shows an older version.
          const hasPdf = await keepPdf(env, existing[0].token, body.pdf, body.number, existing[0].expiresAt ?? null);
          return reply(json({ token: existing[0].token, reused: true, hasPdf }));
        }

        const token = newToken();
        const expiresAt = body.expiresInDays ? new Date(Date.now() + body.expiresInDays * 86_400_000) : null;
        await db.insert(schema.sharedDocuments).values({
          id: uid("sd"), token, orgId: found.session.orgId, documentId: body.documentId,
          number: body.number, snapshot: JSON.stringify(body.snapshot),
          expiresAt, viewCount: 0, createdBy: found.session.userId, createdAt: new Date()
        });
        const hasPdf = await keepPdf(env, token, body.pdf, body.number, expiresAt);

        return reply(json({ token, hasPdf }));
      }

      /* ---------- what the customer actually opens, with no sign-in ---------- */
      if (url.pathname.startsWith("/portal/view/") && req.method === "GET") {
        const token = url.pathname.slice("/portal/view/".length);
        if (!token || token.length < 16) return reply(problem(404, "There is nothing at this link."));

        const rows = await db.select().from(schema.sharedDocuments)
          .where(eq(schema.sharedDocuments.token, token)).limit(1);
        const record = rows[0];

        const state = stateOf(record ? {
          ...record,
          createdAt: record.createdAt ?? new Date(),
          expiresAt: record.expiresAt ?? undefined,
          revokedAt: record.revokedAt ?? undefined
        } as never : undefined);

        if (state !== "live" || !record) {
          const refusal = refusalFor(state);
          return reply(problem(refusal.status, refusal.says));
        }

        await db.update(schema.sharedDocuments)
          .set({ viewCount: (record.viewCount ?? 0) + 1, lastViewedAt: new Date() })
          .where(eq(schema.sharedDocuments.id, record.id));

        const hasPdf = Boolean(await env.SESSIONS.get(`pdfname:${token}`));
        return reply(json({ document: JSON.parse(record.snapshot), hasPdf }));
      }

      /* ---------- the PDF behind a shared link, for anyone holding the link ---------- */
      if (url.pathname.startsWith("/portal/pdf/") && req.method === "GET") {
        const token = url.pathname.slice("/portal/pdf/".length);
        if (!token || token.length < 16) return reply(problem(404, "There is nothing at this link."));

        const rows = await db.select().from(schema.sharedDocuments)
          .where(eq(schema.sharedDocuments.token, token)).limit(1);
        const record = rows[0];
        const state = stateOf(record ? {
          ...record,
          createdAt: record.createdAt ?? new Date(),
          expiresAt: record.expiresAt ?? undefined,
          revokedAt: record.revokedAt ?? undefined
        } as never : undefined);
        // A withdrawn link withdraws the file with it.
        if (state !== "live" || !record) {
          const refusal = refusalFor(state);
          return reply(problem(refusal.status, refusal.says));
        }

        const [bytes, name] = await Promise.all([
          env.SESSIONS.get(`pdf:${token}`, "arrayBuffer"),
          env.SESSIONS.get(`pdfname:${token}`)
        ]);
        if (!bytes) return reply(problem(404, "There is no PDF for this document yet. Ask whoever sent it for a copy."));

        const fileName = name ?? safeFileName(record.number);
        return reply(new Response(bytes, {
          headers: {
            "Content-Type": "application/pdf",
            "Content-Disposition": `${url.searchParams.has("inline") ? "inline" : "attachment"}; filename="${fileName}"`,
            "Cache-Control": "private, no-store",
            "X-Content-Type-Options": "nosniff"
          }
        }));
      }

      /* ---------- withdrawing a link ---------- */
      if (url.pathname === "/portal/revoke" && req.method === "POST") {
        const found = await currentSession(req, env);
        if (!found?.session.orgId) return reply(problem(401, "Not signed in."));
        const body = await req.json().catch(() => null) as { documentId?: string } | null;
        if (!body?.documentId) return reply(problem(400, "Which document?"));

        const withdrawn = await db.select({ token: schema.sharedDocuments.token }).from(schema.sharedDocuments)
          .where(and(
            eq(schema.sharedDocuments.orgId, found.session.orgId),
            eq(schema.sharedDocuments.documentId, body.documentId)
          ));
        await db.update(schema.sharedDocuments).set({ revokedAt: new Date() })
          .where(and(
            eq(schema.sharedDocuments.orgId, found.session.orgId),
            eq(schema.sharedDocuments.documentId, body.documentId)
          ));
        await Promise.all(withdrawn.flatMap((w) => [env.SESSIONS.delete(`pdf:${w.token}`), env.SESSIONS.delete(`pdfname:${w.token}`)]));

        return reply(json({ ok: true }));
      }

      /* ---------- which documents are shared, and whether anybody looked ---------- */
      if (url.pathname === "/portal/shared" && req.method === "GET") {
        const found = await currentSession(req, env);
        if (!found?.session.orgId) return reply(problem(401, "Not signed in."));

        const rows = await db.select().from(schema.sharedDocuments)
          .where(eq(schema.sharedDocuments.orgId, found.session.orgId));

        return reply(json({
          shared: rows.map((r) => ({
            documentId: r.documentId, number: r.number, token: r.token,
            viewCount: r.viewCount ?? 0,
            lastViewedAt: r.lastViewedAt?.toISOString(),
            revoked: Boolean(r.revokedAt),
            expiresAt: r.expiresAt?.toISOString()
          }))
        }));
      }

      /* ---------- a link a customer can pay an invoice through ---------- */
      if (url.pathname === "/payments/link" && req.method === "POST") {
        const found = await currentSession(req, env);
        if (!found?.session.orgId) return reply(problem(401, "Not signed in."));

        const body = await req.json().catch(() => null) as {
          documentId?: string; number?: string; amountMinor?: number; currency?: string;
          description?: string; customer?: { name?: string; email?: string; phone?: string };
          dueDate?: string; returnTo?: string;
        } | null;

        if (!body?.documentId || !body.number || !body.amountMinor || !body.currency) {
          return reply(problem(400, "An invoice id, number, amount and currency are needed."));
        }
        if (body.amountMinor <= 0) return reply(problem(400, "There is nothing to pay on that invoice."));

        // One live link per invoice: a second link for the same bill is how a customer ends up
        // paying twice, and refunding that costs more than the invoice was worth.
        const existing = await db.select().from(schema.paymentLinks)
          .where(and(eq(schema.paymentLinks.orgId, found.session.orgId), eq(schema.paymentLinks.documentId, body.documentId)))
          .limit(1);
        const already = existing[0];
        if (already && !already.paidAt && (!already.expiresAt || already.expiresAt.getTime() > Date.now())) {
          return reply(json({ url: already.url, reference: already.reference, reused: true }));
        }

        const links = linkProvider(env);
        const made = await links.create({
          orgId: found.session.orgId,
          documentId: body.documentId,
          number: body.number,
          amountMinor: body.amountMinor,
          currency: body.currency,
          description: body.description ?? `Invoice ${body.number}`,
          customer: body.customer ?? {},
          dueDate: body.dueDate,
          returnTo: body.returnTo
        });

        if (!made.url) return reply(json({ url: null, connected: links.live, note: made.note }));

        await db.insert(schema.paymentLinks).values({
          id: uid("pl"), orgId: found.session.orgId, documentId: body.documentId, number: body.number,
          amountMinor: body.amountMinor, currency: body.currency, reference: made.reference, url: made.url,
          expiresAt: made.expiresAt ? new Date(made.expiresAt) : null,
          createdBy: found.session.userId, createdAt: new Date()
        });

        return reply(json({ url: made.url, reference: made.reference, expiresAt: made.expiresAt }));
      }

      /* ---------- the provider telling us money arrived ---------- */
      if (url.pathname === "/payments/webhook" && req.method === "POST") {
        const links = linkProvider(env);
        const raw = await req.text();
        const signed = await links.verifyWebhook(raw, req.headers.get("X-Razorpay-Signature"));
        // An unsigned webhook is somebody claiming an invoice was paid. Nothing is recorded.
        if (!signed) return reply(problem(401, "That webhook was not signed by the payment provider."));

        const paid = links.readPaid(raw);
        if (!paid) return reply(json({ ok: true, ignored: true }));

        const rows = await db.select().from(schema.paymentLinks)
          .where(eq(schema.paymentLinks.reference, paid.reference)).limit(1);
        const link = rows[0];
        if (!link) return reply(json({ ok: true, unknown: true }));
        if (link.paidAt) return reply(json({ ok: true, alreadyRecorded: true }));

        await db.update(schema.paymentLinks).set({
          paidAt: new Date(), paidOn: paid.paidOn, paidAmountMinor: paid.amountMinor,
          method: paid.method ?? null, paymentReference: paid.paymentReference ?? null
        }).where(eq(schema.paymentLinks.id, link.id));

        return reply(json({ ok: true }));
      }

      /* ---------- payments the device has not been told about yet ---------- */
      if (url.pathname === "/payments/arrived" && req.method === "GET") {
        const found = await currentSession(req, env);
        if (!found?.session.orgId) return reply(problem(401, "Not signed in."));

        const rows = await db.select().from(schema.paymentLinks)
          .where(and(eq(schema.paymentLinks.orgId, found.session.orgId), eq(schema.paymentLinks.deliveredAt, null as unknown as Date)));

        const notices: PaymentNotice[] = rows
          .filter((r) => r.paidAt && !r.deliveredAt)
          .map((r) => ({
            documentId: r.documentId,
            amountMinor: r.paidAmountMinor ?? r.amountMinor,
            paidOn: r.paidOn ?? new Date().toISOString().slice(0, 10),
            method: r.method ?? undefined,
            reference: r.paymentReference ?? undefined
          }));

        return reply(json({ payments: notices }));
      }

      /* ---------- the device confirming it has applied them ---------- */
      if (url.pathname === "/payments/applied" && req.method === "POST") {
        const found = await currentSession(req, env);
        if (!found?.session.orgId) return reply(problem(401, "Not signed in."));
        const body = await req.json().catch(() => null) as { documentIds?: string[] } | null;
        const ids = (body?.documentIds ?? []).filter((x) => typeof x === "string").slice(0, 200);
        if (ids.length === 0) return reply(json({ ok: true, marked: 0 }));

        await db.update(schema.paymentLinks).set({ deliveredAt: new Date() })
          .where(and(eq(schema.paymentLinks.orgId, found.session.orgId), inArray(schema.paymentLinks.documentId, ids)));

        return reply(json({ ok: true, marked: ids.length }));
      }

      /* ---------- start paying ---------- */
      if (url.pathname === "/billing/checkout" && req.method === "POST") {
        const found = await currentSession(req, env);
        if (!found?.session.orgId) return reply(problem(401, "Not signed in."));
        const member = await membership(db, found.session.userId, found.session.orgId);
        if (member?.role !== "owner") return reply(problem(403, "Only the owner of the organisation can change the plan."));

        const { plan: planId, period } = (await req.json()) as { plan?: string; period?: "monthly" | "yearly" };
        const plan = planById(planId ?? "pro");
        if (plan.id === "free") return reply(problem(400, "The free plan does not need paying for."));

        const current = await allowance(db, found.session.orgId);
        const provider = paymentProvider(env);
        const session = await provider.createCheckout({
          orgId: found.session.orgId,
          email: found.session.email,
          plan,
          price: priceFor(plan, current?.org.country ?? "IN"),
          period: period === "yearly" ? "yearly" : "monthly",
          returnUrl: `${env.APP_ORIGIN}/settings/`
        });

        await audit(db, req, { orgId: found.session.orgId, userId: found.session.userId, action: "billing.checkout", summary: `${plan.id} ${period ?? "monthly"} via ${provider.name}` });
        return reply(json({ ...session, provider: provider.name, connected: provider.live }));
      }

      /* ---------- the provider telling us what happened ---------- */
      if (url.pathname === "/billing/webhook" && req.method === "POST") {
        const body = await req.text();
        const provider = paymentProvider(env);
        const signature = req.headers.get("X-Razorpay-Signature");
        if (!(await provider.verifyWebhook(body, signature))) return reply(problem(400, "That webhook could not be verified."));

        const event = JSON.parse(body) as { event?: string; payload?: { subscription?: { entity?: { id?: string; status?: string; notes?: { orgId?: string }; current_end?: number; plan_id?: string } } } };
        const sub = event.payload?.subscription?.entity;
        const orgId = sub?.notes?.orgId;
        if (!orgId) return reply(json({ ok: true, ignored: "no organisation on the event" }));

        const active = sub?.status === "active" || sub?.status === "authenticated";
        await db.update(schema.organisations)
          .set({ plan: active ? "pro" : "free", trialEndsAt: null })
          .where(eq(schema.organisations.id, orgId));

        await db.insert(schema.subscriptions).values({
          id: uid("sb"), orgId, provider: provider.name, providerRef: sub?.id ?? "unknown",
          plan: "pro", status: active ? "active" : "cancelled", currency: "INR", amountMinor: 0,
          currentPeriodEnd: sub?.current_end ? new Date(sub.current_end * 1000) : null,
          createdAt: new Date(), updatedAt: new Date()
        });

        await audit(db, req, { orgId, action: "billing.webhook", summary: `${event.event ?? "event"} -> ${active ? "active" : "inactive"}` });
        return reply(json({ ok: true }));
      }

      /* ---------- reading a photographed bill ---------- */
      if (url.pathname === "/receipts/read" && req.method === "POST") {
        const found = await currentSession(req, env);
        if (!found?.session.orgId) return reply(problem(401, "Sign in to have receipts read for you."));

        const service = receiptService(env);
        if (!service.connected) {
          return reply(problem(501, "Reading receipts automatically is not connected yet. Attach the photo and type the details, which still keeps the paperwork with the money."));
        }

        const allowed = await allowance(db, found.session.orgId);
        if (!allowed?.limits.receiptReading) {
          return reply(problem(402, "Reading a bill from a photograph is part of Pro. You can still attach the photo and type the details.", { plan: allowed?.plan.id ?? "free" }));
        }

        if (!(await rateLimit(env.SESSIONS, `ocr:${found.session.orgId}`, 60, 60 * 60 * 1000))) {
          return reply(problem(429, "That is a lot of receipts in one hour. Try again shortly."));
        }

        const { dataUrl } = (await req.json()) as { dataUrl?: string };
        if (!dataUrl || dataUrl.length > 8_000_000) return reply(problem(400, "Send one image, under about six megabytes."));

        const receipt = await service.read(dataUrl);
        if (!receipt) return reply(problem(502, "That receipt could not be read. Type the details instead."));

        await audit(db, req, { orgId: found.session.orgId, userId: found.session.userId, action: "receipt.read", summary: service.name });
        return reply(json(receipt));
      }

      /* ---------- what you want to hear about ---------- */
      if (url.pathname === "/notifications/preferences") {
        const found = await currentSession(req, env);
        if (!found?.session.orgId) return reply(problem(401, "Not signed in."));
        const orgId = found.session.orgId;

        if (req.method === "POST") {
          const allowed = await allowance(db, orgId);
          const body = (await req.json()) as { weeklyDigest?: boolean; overdueAlerts?: boolean };
          if ((body.weeklyDigest || body.overdueAlerts) && !allowed?.limits.reminders) {
            return reply(problem(402, "Email reminders are part of Pro.", { plan: allowed?.plan.id ?? "free" }));
          }
          const existing = (await db.select().from(schema.notificationPrefs)
            .where(and(eq(schema.notificationPrefs.userId, found.session.userId), eq(schema.notificationPrefs.orgId, orgId))).limit(1))[0];

          const values = {
            userId: found.session.userId, orgId,
            weeklyDigest: Boolean(body.weeklyDigest), overdueAlerts: Boolean(body.overdueAlerts),
            updatedAt: new Date()
          };
          if (existing) await db.update(schema.notificationPrefs).set(values).where(eq(schema.notificationPrefs.id, existing.id));
          else await db.insert(schema.notificationPrefs).values({ id: uid("np"), ...values });

          await audit(db, req, { orgId, userId: found.session.userId, action: "notifications.changed", summary: `digest ${values.weeklyDigest}, overdue ${values.overdueAlerts}` });
          return reply(json({ ok: true, ...values }));
        }

        const row = (await db.select().from(schema.notificationPrefs)
          .where(and(eq(schema.notificationPrefs.userId, found.session.userId), eq(schema.notificationPrefs.orgId, orgId))).limit(1))[0];
        const plan = await allowance(db, orgId);
        return reply(json({
          weeklyDigest: row?.weeklyDigest ?? false,
          overdueAlerts: row?.overdueAlerts ?? false,
          lastSentAt: row?.lastSentAt?.getTime() ?? null,
          allowed: plan?.limits.reminders ?? false,
          plan: plan?.plan.id ?? "free",
          trialing: plan?.trialing ?? false
        }));
      }

      /* ---------- a preview, so nobody has to wait a week to see what it says ---------- */
      if (url.pathname === "/notifications/preview") {
        const found = await currentSession(req, env);
        if (!found?.session.orgId) return reply(problem(401, "Not signed in."));
        const digest = await digestFor(db, found.session.orgId, new Date().toISOString().slice(0, 10));
        return reply(json(digest));
      }

      /* ---------- take everything with you ---------- */
      if (url.pathname === "/account/export") {
        const found = await currentSession(req, env);
        if (!found?.session.orgId) return reply(problem(401, "Not signed in."));
        const rows = await db.select().from(schema.records).where(eq(schema.records.orgId, found.session.orgId));
        return reply(json({
          exportedAt: new Date().toISOString(),
          organisation: found.session.orgId,
          records: rows.map((r) => ({ kind: r.kind, localId: r.localId, body: JSON.parse(r.body), updatedAt: r.updatedAt.getTime(), deletedAt: r.deletedAt?.getTime() ?? null }))
        }));
      }

      return reply(problem(404, "No such endpoint."));
    } catch (error) {
      console.error("Request failed:", error);
      return reply(problem(500, "Something went wrong here. Nothing was changed."));
    }
  }
} satisfies ExportedHandler<Env>;
